Project Name: Tasteless Beige Wall-E
Project Version: #1b5332ad
Project Url: https://www.flux.ai/vkaleb/tasteless-beige-wall-e

Project Description:
60mm x 60mm 4-Layer ESP32-S3 & BM1398 ASIC Multi-Rail Control Board

Project Properties:

Board Size:
60mm x 60mm

PCB Layers:
4

Main MCU:
ESP32-S3

ASIC:
BM1398

Power Rails:
+5V, 3.3V, 1.8V, 0.8V, 0.32–0.36V

Power Requirements:
USB

Connectivity:
WiFi

Domain:
Consumer Electronics

Project Description:
60mm x 60mm 4-Layer ESP32-S3 + BM1398 ASIC Multi-Rail Control Board


